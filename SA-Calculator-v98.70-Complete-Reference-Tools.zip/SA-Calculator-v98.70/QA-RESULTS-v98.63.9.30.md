# QA results — v98.63.9.30

- Release regression: **38/38 PASS**.
- Scientific grid: exactly 16 function buttons; no plus or More overlay IDs.
- INV HTML pair mappings verified across trig, ln/eˣ, log/10ˣ, root/square, cube-root/cube, and xʸ/negative power.
- Calculator numeric tests for inverse functions and power/root paths pass.
- Scientific font-size and 20px keypad reduction CSS assertions pass.
- `npm run build:web`: PASS; required web assets generated.
- Root and `www` HTML, JS, CSS, manifest and service-worker cache copies synchronized.
- Workflow YAML source updated to v98.63.9.30 and versionCode 1098078.
- APK assembly and device-side rendering/touch test: **not run locally**.
