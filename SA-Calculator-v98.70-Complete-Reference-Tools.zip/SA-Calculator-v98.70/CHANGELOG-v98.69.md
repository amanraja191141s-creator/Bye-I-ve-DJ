# SA Calculator v98.69 — Tool Suite Removal

Removed GST, Loan/EMI, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age Calculator and BMI Calculator from the application UI and runtime. Their screens, navigation cards, calculation modules, initialization hooks, startup/favorites registrations, currency catalog and screen-specific CSS were removed. The main calculator and unrelated utilities remain.

Release identity: `1.98.83-v98.69`; Android version code: `1098090`.
