# SA Calculator v98.68 — Full tool UI rebuild

## Exact scope
All 12 tools: GST, Loan/EMI, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age and BMI.

## Rebuild
- Replaced the accumulated v98.67 tool-reference stylesheet with one canonical, compact layout layer.
- Removed conflicting old tool-layer sizing and keypad geometry from the active reference stylesheet.
- Standardized title toolbar, screen scroll plane, card dimensions, input typography, result wrapping, button sizes and active states.
- Resized the shared keypad to approximately 40% of tall-screen height (up to 620px), matching the supplied 4-row screenshot proportions.
- Kept the keypad app-anchored and fixed while the input/result workspace scrolls above it.
- Unit categories now render as a horizontal scroll row and selected category state is exposed accessibly.
- Explicitly preserved hidden state for inactive unit workspace and other hidden panels.
- Kept theme surface/text variables connected; coral remains the tool action accent.
- Preserved calculator logic, IDs, currency refresh, history, settings and navigation.

## Validation boundary
Automated source tests and generated-web-bundle checks are run for this release. They do not prove zero lag, exact physical-device pixel rendering, APK installation, or runtime API connectivity. Those require GitHub APK build and target Android device verification.

## Release identity
- App version: `1.98.82-v98.68`
- Android versionCode: `1098089`
- Service worker cache namespace: `v9868`
