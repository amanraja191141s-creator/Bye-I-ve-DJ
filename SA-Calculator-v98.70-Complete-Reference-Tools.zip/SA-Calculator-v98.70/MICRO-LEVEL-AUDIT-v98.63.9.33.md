# Micro-level audit — v98.63.9.33

## Root causes found
- Legacy embedded `.dock-keypad` elements coexisted with the shared `#popup-keypad-sheet`, leaving multiple keypad implementations in the same Tools experience.
- Tool navigation explicitly cleared active input and kept the shared keypad closed, unlike the supplied reference video where the keypad is already docked on entry.
- The shared keypad still contained modal-era overlay/header/value-preview markup and numerous historical CSS overrides.
- Android workflow retained v98.63.9.31 labels and required-file checks while selecting v98.63.9.32, and did not provision Android SDK packages before checking them.

## Corrections
- Removed embedded legacy numeric keypads from currency, unit, discount and percent screens. The dedicated hexadecimal keypad remains separate because it supports A–F and base-specific actions.
- Removed modal overlay/header/preview markup; the active field is the source of truth for the shared keypad.
- On entering a numeric tool, the first visible editable field is focused and the shared docked keypad opens.
- Equals and Calculate retain the keypad and reveal the result above its top boundary.
- Main calculator keypad remains unchanged.
- Workflow now validates current release metadata/tests dynamically, provisions Android API 35 + Build Tools 35.0.0 + platform tools, and verifies adb/aapt before building.

## Verification limits
Local checks do not prove a hosted Gradle/APK build or physical-device rendering. Those must be confirmed by the resulting GitHub Actions run and Android device test.
