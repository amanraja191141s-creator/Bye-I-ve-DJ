# Video reference corrections — v98.63.9.36

- Aligned Tip Calculator result card with the recording: Per Person Amount, Total Tip, Per Person Tip and Total Bill Amount.
- Added SIP Delay Cost's fourth “In today’s money value” output using a documented illustrative 6% annual inflation assumption.
- Added exact sample regression checks for the four Tip outputs and SIP present-value display.
- Synchronized canonical HTML/JS with the Android `www/` bundle.
- Recorded the unexplained SIP reference-number discrepancy rather than silently changing the financial formula.
