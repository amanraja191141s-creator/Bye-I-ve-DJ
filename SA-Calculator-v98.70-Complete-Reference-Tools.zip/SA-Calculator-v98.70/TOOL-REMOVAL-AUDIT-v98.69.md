# Tool Removal Audit v98.69

Removed tool IDs: `salestax`, `loan`, `savings`, `salary`, `tip`, `sip`, `currencies`, `discount`, `percent`, `units`, `agecalc`, `bodymetrics`.

Removed from HTML screen/menu markup, dedicated JavaScript calculator modules and initialization, favorites/startup routing, currency and unit catalogues, screen-specific CSS, the tool-only stylesheet, currency-name catalog and service-worker asset list. Main calculator, date, fuel, GPA, number-base, unit-price and world-time utilities are retained.

Automated source tests do not prove physical-device performance or APK runtime behavior.
