# Micro audit — v98.63.9.29

## Video issue
The scientific keypad controls were visually larger than the basic calculator keys and the drawer was forced to a viewport-based height. This made the scientific panel height inconsistent with the numeric keypad band and exaggerated the INV key.

## Correction
- Drawer geometry is read from the actual `.main-keypad` rectangle by existing `syncDrawerGeometry()` and applied with CSS variables.
- Button text scale is capped at 22 CSS px (same scale as the standard keypad), labels wrap rather than clipping, and INV is plain/unboxed.
- More and its close button are compact circular controls contained within the 4×4 cell.
- The scientific overlay is hidden/noninteractive when closed and keeps the existing swipe and Escape pathways.
- Root and generated web CSS are synchronized; service-worker cache namespace is changed to avoid stale installed CSS.

## Remaining verification limits
No headless browser screenshot was produced because the installed Chromium instance is blocked by environment policy. Android APK build/install and physical touch/render tests have not been run.
