# SA Calculator v98.68 — All-tools reference layout and docked keypad alignment

## Exact tool inventory
The v98.68 UI pass covers all 12 calculator tools in the active Tools catalogue:
1. GST Calculator (`salestax`)
2. Loan / EMI Calculator (`loan`)
3. Saving Calculator (`savings`)
4. Salary Calculator (`salary`)
5. Tip Calculator (`tip`)
6. SIP Calculator (`sip`)
7. Currency Converter (`currencies`)
8. Discount Calculator (`discount`)
9. Percentage Calculator (`percent`)
10. Unit Converter (`units`)
11. Age Calculator (`agecalc`)
12. BMI Calculator (`bodymetrics`)

## UI/layout changes
- Applied one authoritative responsive screen layout to all 12 tool screens.
- Kept the input and result workspace scrollable above the single shared docked keypad.
- Kept the 4-column numeric keypad, AC, delete, decimal, 00 and tall equals key.
- Equals recalculates the active tool, keeps the keypad open and scrolls results into the unobstructed area above it.
- Unified card surfaces, borders, input typography, result number wrapping and touch handling.
- Added narrow-screen, short-screen, landscape and reduced-motion fallbacks.
- Preserved tool-specific controls, original calculation IDs, event wiring, history/settings and navigation.

## QA boundaries
- Automated source and regression tests are run locally and reported in the release verification file.
- Automated CSS/source checks do not prove physical-device frame rate or zero lag.
- Android APK build/install and real-device visual/touch testing must complete in GitHub Actions and on target Android devices before production sign-off.

## Release identity
- App version: `1.98.82-v98.68`
- Android versionCode: `1098089`
- Service worker cache namespace: `v9868`
