import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('CI caches npm downloads without requiring a missing lockfile', () => {
  assert.equal(fs.existsSync('package-lock.json'), false,
    'this release intentionally uses npm install without a committed lockfile');
  assert.ok(workflow.includes('uses: actions/cache@v4'));
  assert.ok(workflow.includes('path: ~/.npm'));
  assert.ok(workflow.includes("hashFiles('**/package.json')"));
  assert.ok(workflow.includes('npm-${{ runner.os }}-node22-'));
  assert.ok(workflow.includes('package-manager-cache: false'));
});

test('npm cache is restored before dependency installation', () => {
  assert.ok(workflow.indexOf('name: Cache npm downloads') < workflow.indexOf('name: Install npm dependencies'));
  assert.ok(pkg.dependencies['@capacitor/core']);
  assert.ok(pkg.dependencies['@capacitor/android']);
});
