# Micro-level audit — v98.63.9.35

## Evidence reviewed
- `Screenrecording_20261122_132803.mp4`
- `Screenrecording_20261122_132936.mp4`
- v98.63.9.34 Action hotfix source ZIP and both workflow copies.

## Confirmed video defect
The dark-theme Saving/Unit Price/Unit Converter tool screens showed a tall, almost full-width bottom dock, but the numeric keys were compressed into a tiny group at the lower-right. Most of the dock remained empty. The keypad did not match the full-width key sizing/spacing seen in the light-theme converter recording.

## Structural correction
- The keypad dock is now absolutely anchored to `#app-container` (`inset:auto 0 0 0; width:100%`) rather than using viewport-fixed `100vw` geometry from inside a nested app stacking context.
- `#app-container` establishes the containing block.
- The dock is a flex column; the grid is an explicit `flex:1` child with four equal columns and four equal rows.
- Every key stretches to its grid cell and uses `aspect-ratio:auto`, removing the square intrinsic sizing constraint.
- The equals key continues to span the last two rows.
- Compact-height and landscape sizing rules are included.
- The same dock-height token drives scroll padding and the active field/result reveal boundary.
- Existing popup markup is absent; the shared dock remains separate from the main calculator and HEX keypad.

## Actions/workflow audit
- Release identity is aligned at `1.98.78-v98.63.9.35`, Android versionCode `1098083`.
- Service-worker cache namespace and workflow check both use `v9863935`.
- Workflow checks the exact source identity, required source assets, explicit release tests, Android SDK tools, generated web bundle, APK metadata and SHA-256.
- npm install uses retries and does not create an incidental lockfile.
- Gradle cache setup and Android SDK setup are ordered before build steps.
- Artifact upload fails if the APK is missing.
- Standalone YAML and `.github/workflows/main.yml` are byte-identical.

## Local verification
57/57 release tests pass; web bundle build, JS syntax, PostCSS, YAML parse, required-file checks, source/www parity and ZIP integrity pass.

## Limits
The supplied Actions log excerpt contained no explicit failed step or error text. No GitHub-hosted run or physical Android/WebView test has been executed here. Those cannot honestly be marked as passed without a fresh hosted run/device test.
