# SA Calculator v98.69 — Focused Calculator Workspace

SA Calculator is a mobile-first calculator app with standard/scientific calculation, history, favorites, themes, localization, and focused utilities. The following twelve tool modules have been removed completely from the shipped UI and runtime: GST, Loan/EMI, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age Calculator and BMI.

## Release identity
- App version: `1.98.83-v98.69`
- Android versionCode: `1098090`
- Active screens: Calculator, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Unit Price, World Time, Tools, Favorites and Settings.
- Android workflow: `Android-Workflow-v98.69.yml`

## Verify locally
```sh
npm test
npm run build:web
```

## Android APK
Copy `Android-Workflow-v98.69.yml` to `.github/workflows/main.yml`, commit the complete project, and run the workflow in GitHub Actions. It generates/synchronizes the Capacitor Android project and assembles a debug APK. The source archive does not include a prebuilt APK.

## Validation boundary
The v98.69 release passes 38 automated regression tests, JavaScript syntax checks, CSS parsing, workflow YAML parsing, removal-scope checks and Android web-bundle synchronization. Android APK compilation, installation, physical-device layout, frame rate and memory pressure still require GitHub Actions and target-device testing. Automated tests do not prove zero lag or zero bugs on every Android device.
