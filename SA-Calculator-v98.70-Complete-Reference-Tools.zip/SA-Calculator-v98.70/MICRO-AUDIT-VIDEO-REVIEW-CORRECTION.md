# Micro audit — recording review correction (v98.63.9.26)


## Directly observed in Screenrecording_20261121_190114.mp4
- Expanded scientific function layer was bright pink, low contrast, and occupied the full drawer, obscuring useful context and looking unlike the dark calculator palette.
- Scientific additional-function buttons were not consistently distinguishable from the background.
- Tools catalogue showed lower rows close to/under the fixed bottom navigation. The recording did not show a successful scroll all the way to the last group, so visibility of the final tiles was not demonstrated.
- Unit picker had a fixed header/search and a scrollable list; at the selected-option transition a row appeared partly clipped near the search boundary.

## Corrections applied
- Expanded scientific panel constrained to function region with dark navy background, border, rounded card and shadow.
- Additional function buttons have consistent 44px minimum hit area, dark cards and high-contrast text.
- Scientific base function buttons darkened and contrast improved.
- Tools screen retains independent vertical scrolling and receives bottom padding/scroll-padding for the dock navigation.
- Tool group receives larger bottom reserve; tool cards get scroll margin.
- Unit picker panel/list flex sizing is explicitly bounded; header/search do not shrink; options list scrolls separately and uses scroll padding.
- Added four correction-specific regression tests and included them in `npm test` release gate.

## Not verified in this environment
- Android APK build/install and touch latency on a physical device.
- Real viewport rendering after CSS patch (Chromium is present but no browser automation harness installed).
- Whether scrolling reaches the very last tool tile in every OEM viewport; source CSS now reserves space, but device proof is pending.
- Runtime screenshots of the revised scientific panel and picker.
