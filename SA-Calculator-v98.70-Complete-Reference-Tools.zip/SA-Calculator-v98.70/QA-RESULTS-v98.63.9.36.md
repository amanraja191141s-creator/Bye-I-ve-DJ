# QA results — v98.63.9.36

## Automated checks
- `node --check assets/js/app.js`: PASS
- `npm run build:web`: PASS — 13 required web assets verified
- `npm run test:release`: PASS — 59 tests, 59 passed, 0 failed
- CSS parser: PASS — 0 parse errors
- HTML IDs: PASS — no duplicate IDs
- Source / `www` HTML, CSS and JS parity: PASS
- Standalone / GitHub Actions workflow byte parity: PASS
- Android workflow YAML parse: PASS
- ZIP integrity: verified after packaging

## Release identity
- App version: `1.98.78-v98.63.9.36`
- Android versionCode: `1098084`

## Not run
Browser visual rendering, Android emulator / physical-device interaction, hosted GitHub Actions, and APK generation were not run in this environment. Device-specific layout, touch feel, frame-time performance and final APK behavior are therefore not certified.
