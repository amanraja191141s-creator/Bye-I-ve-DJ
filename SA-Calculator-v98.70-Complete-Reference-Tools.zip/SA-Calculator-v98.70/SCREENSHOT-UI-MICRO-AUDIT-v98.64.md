# Screenshot UI Micro Audit — v98.64

## Supplied references inspected
Ten Android screenshots, uploaded in chronological order from Salary Calculator through BMI Calculator. They show Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age Calculator (form and date picker), and BMI Calculator.

## Reference-derived design requirements
1. Pale neutral app canvas and white rounded input cards with subtle grey borders/shadows.
2. Coral-red primary actions and active segments; pale pink icon tiles; grey inactive segments.
3. Large dark numeric values and muted placeholders, with labels above values.
4. Shared bottom numeric keypad: 7-8-9-AC / 4-5-6-backspace / 1-2-3-equals / 00-0-decimal; equals spans the last two rows.
5. Keypad must not cover form controls, result content, or ad/footer safe area.
6. BMI screen presents Weight and Height cards, kg/lbs and cm/in selectors, and BMI result.
7. Age screen uses a native date picker with cancel/confirm behaviour and rejects future/impossible dates.
8. Unit screen keeps category chips horizontally scrollable and shows the selected conversion pair beneath them.
9. Currency screen keeps source/target currency selectors and amount/result values distinct; rate freshness/status remains visible.
10. Financial tools retain their domain-specific fields/results while sharing the same visual components.

## Implemented
- Coral reference skin applied to all tool screens and shared keypad.
- BMI kg/lbs and cm/in switching with value conversion and normalized BMI math.
- Unit Converter starts in Weight mode and leaves category chips visible while the conversion workspace is open.
- Age date input and all existing validation/calculation handlers retained.
- Existing 12-tool scope and event target IDs retained.

## Verification boundary
Automated release tests validate source contracts and representative calculator math. They do not prove exact pixel parity on every Android WebView, physical touch latency, ad SDK layout, or native date-picker appearance across vendors. Final device QA remains required.
