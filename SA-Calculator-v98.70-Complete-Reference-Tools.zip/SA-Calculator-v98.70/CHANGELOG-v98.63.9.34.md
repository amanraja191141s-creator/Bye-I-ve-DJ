# SA Calculator v98.63.9.34

## Video-driven Tools keypad correction

- Replaced the legacy popup keypad DOM identity and event attributes with one shared `tool-keypad-dock` component.
- Removed historical popup/modal keypad CSS rules and the conflicting undersized 17dvh key sizing overrides.
- Made the shared keypad full viewport width with a four-column, four-row grid whose key cells stretch to their grid tracks.
- Kept the calculator's primary keypad and the dedicated hexadecimal keypad separate and unchanged.
- Changed active-field scrolling to use the measured dock top edge instead of a hard-coded viewport ratio.
- Changed result reveal to measure every currently visible result card and scroll its lowest visible edge above the dock.
- Rotated the service-worker cache namespace and aligned app, manifest, package, Android version code and workflow identities.

## Android Actions hardening

- Added Gradle setup/cache before Android build steps.
- Android SDK API 35, Build Tools 35.0.0 and platform-tools are explicitly installed and verified.
- Exact checked-out source is preferred when its package version matches; archive scanning is used only when the checkout is stale.
- Duplicate exact source archives are accepted only when byte-identical.
- npm install does not create a lockfile and uses network retry/timeout settings.
- Release workflow and its standalone YAML mirror are synchronized.
