# Micro-level audit — v98.63.9.16

## Video source reviewed
`Screenrecording_20261120_141502.mp4` — 720×1560, approximately 93.2 seconds, 12.69 fps.
Representative points reviewed across the recording:
- Currency converter screen: the selected currency identity showed a placeholder-like grey dot instead of a clear flag.
- Unit converter: opening the From Unit selector showed unit names broken into very narrow fragments. The picker grid reserved a 38px first column even though unit rows have no flag element.
- The selectors initially showed only the current selection; the user had to type in search before alternatives appeared.

## Root causes found
1. `renderOptions()` returned early for every unselected currency/unit option while the search query was empty or shorter than two characters.
2. Search rendering was capped to eight results, despite the full supported catalogue containing 105 currencies.
3. A shared option grid reserved a flag column for unit rows. Because unit rows do not have a flag node, the label was placed in that narrow first column and wrapped/clipped.
4. Currency flags were emoji text inside the generated `.sumaire-select-flag` trigger node, while legacy `.currency-flag` spans are intentionally hidden after the custom trigger is built. The actual trigger flag needed an explicit WebView emoji font stack and visible flag-tile geometry.
5. Opening the list auto-scrolled the currently selected unit into view, which could make the top of the full list appear missing.

## Corrections
- Removed selected-only and two-character gating. Every enabled option is rendered on first open.
- Search is now an optional live filter from one character; no artificial eight-row cap remains.
- Currency option rows use a three-column grid: flag, localized name/code/region, selected indicator.
- Unit option rows use a two-column grid: full-width unit label, selected indicator.
- The actual `.sumaire-select-flag` trigger node and currency list rows explicitly display their flag glyphs; hidden legacy spans remain hidden by design.
- The picker no longer auto-scrolls the selected unit away from the first visible rows when opening.
- The list remains vertically scrollable inside a bounded mobile sheet.

## Regression coverage
- Updated prior tests that asserted selected-only behavior, since that behavior contradicted the requested UX.
- Added dedicated tests for full initial catalog visibility, search filtering, currency flag markup, unit row grid sizing, selected flag visibility and scrollable picker layout.
- Existing currency-rate, swap, amount editing, unit conversion and calculator regression suites remain included.

## Verification boundaries
Automated tests and the web bundle can be verified in this environment. Actual Android WebView rendering, touch interaction and device-specific emoji fallback must still be checked by installing the fresh APK on the target phone.
