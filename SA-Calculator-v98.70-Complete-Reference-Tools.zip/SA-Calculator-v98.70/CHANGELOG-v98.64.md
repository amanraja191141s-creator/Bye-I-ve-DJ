# SA Calculator v98.64 — Screenshot-matched tool UI

## Reference scope
Applied the ten supplied Android screenshots as the visual reference for the 12-tool release.

## UI changes
- Unified tool screens around the reference light-grey canvas, white rounded cards, coral-red actions, soft pink icon surfaces, readable large numeric values and consistent spacing.
- Rebuilt the shared numeric tool keypad skin to match the 4-column, 4-row reference arrangement, with AC, backspace and vertically spanning equals action.
- Added BMI weight kg/lbs and height cm/in segmented selectors; conversions are normalized before BMI calculation and preserve the entered measurement when switching units.
- Simplified BMI presentation to the reference's two measurement cards and BMI result; retained the existing hidden BMR compatibility fields/calculation path.
- Kept Android's native date input interaction for Age Calculator and styled the visible field to match the supplied card design.
- Unit Converter now opens with Weight selected and keeps the horizontally scrollable category selector visible above the conversion workspace.
- Tuned Currency, Discount, Percentage, GST, Loan, Saving, Salary, SIP and Tip form/result surfaces to the same visual language.
- Preserved the exact 12-tool launcher scope and existing calculation/navigation IDs.

## Build identity
- App version: `1.98.79-v98.64`
- Android versionCode: `1098085`
- Service-worker cache namespace updated to v98.64 to avoid stale UI assets.

## Verification
- JavaScript syntax check: PASS
- Android web bundle preparation: PASS (13 required assets verified)
- Release regression suite: 65/65 PASS
- ZIP integrity: verified after packaging
- Physical Android rendering, touch testing and APK installation: NOT RUN in this environment; validate on target devices before production release.
