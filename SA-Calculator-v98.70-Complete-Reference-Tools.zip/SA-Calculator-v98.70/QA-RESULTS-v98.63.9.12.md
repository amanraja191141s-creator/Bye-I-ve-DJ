# QA Results — v98.63.9.12

## Automated checks
- `node --check assets/js/app.js`: PASS
- Focused v98.63.9.12 layout/converter tests: 3/3 PASS
- Full `npm test`: 384/384 PASS
- `node scripts/prepare-android-web.mjs`: PASS (13 required assets verified; canonical stylesheet copied)
- Android workflow file synchronized with `.github/workflows/main.yml`.

## Scope verified
- Calculator-first workspace: global header hidden only while standard calculator is active; primary nav label is Calculator.
- Calculator display/keypad proportions: display flex-basis 46%; keypad flex-basis 54%; five equal keypad rows.
- Currency screen: descriptive copy hidden while selected currency identity, input fields, swap and refresh controls remain.
- Unit screen: descriptive headings/helper note hidden while category/unit selectors, selected values, input/result, swap and Convert controls remain.

## Not verified on a physical device
- APK installation and runtime behavior on a specific Android handset.
- Frame-time/performance benchmarking under real device load.
- Live third-party exchange-rate provider availability.

The automated suite passing is not a guarantee of zero defects on every device.
